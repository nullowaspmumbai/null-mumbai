//
// Created by adhokshajmishra on 23/4/20.
//

#include <iostream>
#include <sys/mman.h>
#include <unistd.h>
#include <vector>

bool removeBreakpoint(unsigned char* func, const std::vector<unsigned int>& offsets,
        const std::vector<unsigned char>& original_bytes)
{
    bool result = false;

    if (offsets.size() > original_bytes.size())
        return false;

    long pagesize = sysconf(_SC_PAGESIZE);
    unsigned long page_start = (unsigned long)func & ~(pagesize - 1);

    if (mprotect((void*)page_start, pagesize, PROT_READ | PROT_WRITE | PROT_EXEC) != 0)
    {
        std::cerr << "mprotect() failed" << std::endl;
        return false;
    }

    for (auto i = 0; i < offsets.size(); ++i)
    {
        if (*(func + offsets[i]) != original_bytes[i]) {
            *(func + offsets[i]) = original_bytes[i];
            result = true;
        }
    }

    return result;
}

bool isBreakpointPresent(const unsigned char *func, const std::vector<unsigned int>& offsets)
{
    bool result = false;

    for (auto &i : offsets) {
        if (*(func + i) == 0xCC)
        {
            result = true;
            break;
        }
    }

    return result;
}

void secret()
{
    for (int i = 0; i < 10; ++i)
    {
        std::cout << "Try a breakpoint at secret()" << std::endl;
    }
}

int main()
{
    auto *ptr_secret = (unsigned char*)secret;

    std::vector<unsigned int> offsets = {0, 1, 4, 8, 15, 19, 21, 28, 35, 40, 43, 50, 53, 56, 61, 65, 67, 68, 69};
    std::vector<unsigned char> original_bytes = {0x55, 0x48, 0x48, 0xc7, 0x83, 0x7f, 0x48, 0x48, 0xe8, 0x48, 0x48,
                                                 0x48, 0x48, 0xe8, 0x83, 0xeb, 0x90, 0xc9, 0xc3};

    /*
    for (auto &offset : offsets)
    {
        original_bytes.push_back(*(ptr_secret + offset));
    }

    std::ios_base::fmtflags f(std::cout.flags());

    for (auto &raw_byte : original_bytes)
    {
        std::cout << "0x" << std::hex << static_cast<unsigned short>(raw_byte) << ", ";
    }

    std::cout.flags(f);
    std::cout<<std::flush;
    */

    if (isBreakpointPresent(ptr_secret, offsets)) {
        std::cerr << "Breakpoint detected" << std::endl;
        if (removeBreakpoint(ptr_secret, offsets, original_bytes)) {
            std::cout << "Breakpoint removed" << std::endl;
            secret();
        }
        else
            std::cerr << "Cannot remove breakpoint" << std::endl;
    }
    else
        secret();
    return 0;
}