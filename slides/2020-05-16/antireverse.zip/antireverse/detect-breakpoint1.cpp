//
// Created by adhokshajmishra on 22/4/20.
//

#include <iostream>

bool isBreakpointPresent(unsigned char *func)
{
    bool result = *func == 0xCC;
    return result;
}

void secret()
{
    for (int i = 0; i < 10; ++i)
    {
        std::cout << "Try a breakpoint at secret()" << std::endl;
    }
}

int main()
{
    auto *ptr_secret = (unsigned char*)secret;
    if (isBreakpointPresent(ptr_secret))
        std::cerr << "Breakpoint detected" << std::endl;
    else
        secret();
    return 0;
}