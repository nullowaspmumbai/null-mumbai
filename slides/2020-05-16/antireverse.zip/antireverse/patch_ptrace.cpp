//
// Created by adhokshajmishra on 22/4/20.
//

long ptrace(int request, int pid, int addr, int data)
{
    return 0;
}
