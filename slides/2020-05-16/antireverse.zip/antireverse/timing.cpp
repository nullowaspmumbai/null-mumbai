//
// Created by adhokshajmishra on 22/4/20.
//

#include <iostream>
#include <chrono>
#include <filesystem>
#include <string>
#include <thread>

using namespace std::chrono_literals;

int main() {
    std::chrono::steady_clock::time_point begin, end;
    std::cout << "Hello, World!" << std::endl;

    while (true) {
        begin = std::chrono::steady_clock::now();
        for (auto &p : std::filesystem::directory_iterator("/proc")) {
            std::string pid = p.path().filename().string();

            try {
                long _pid = std::stol(pid);
                std::cout << _pid << " " << std::flush;
            }
            catch (...) {
                continue;
            }
        }
        std::this_thread::sleep_for(1s);
        end = std::chrono::steady_clock::now();

        unsigned long duration = std::chrono::duration_cast<std::chrono::microseconds>(end - begin).count();

        if (duration > 1010000) {
            std::cerr << "Debugging attempt detected (" << duration << " us)" << std::endl;
            break;
        }
    }

    return 0;
}